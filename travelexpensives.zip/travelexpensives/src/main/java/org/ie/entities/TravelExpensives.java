package org.ie.entities;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
@Entity
public class TravelExpensives {
    @Id
    private Date date;
    @OneToMany(targetEntity = Metro.class,cascade = CascadeType.ALL,orphanRemoval = true)
    @PrimaryKeyJoinColumn(name = "METRO_PRICE")
    private List<Metro> metroList;
    @OneToMany(targetEntity = Bike.class,cascade = CascadeType.ALL,orphanRemoval = true)
    @PrimaryKeyJoinColumn(name = "BIKE_PRICE")
    private List<Bike> bikes;

    @Override
    public String toString() {
        return "TravelExpensives{" +
                "date=" + date +
                ", metroList=" + metroList +
                ", bikes=" + bikes +
                '}';
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setMetroList(List<Metro> metroList) {
        this.metroList = metroList;
    }

    public void setBikes(List<Bike> bikes) {
        this.bikes = bikes;
    }

    public Date getDate() {
        return date;
    }

    public List<Metro> getMetroList() {
        return metroList;
    }

    public List<Bike> getBikes() {
        return bikes;
    }
}
