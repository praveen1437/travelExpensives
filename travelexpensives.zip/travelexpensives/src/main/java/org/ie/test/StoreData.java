package org.ie.test;

import org.ie.entities.Bike;
import org.ie.entities.Metro;
import org.ie.entities.TravelExpensives;
import org.ie.util.HibernateCurdUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class StoreData {
    public static void main(String[] args) {
        HibernateCurdUtil hibernateCurdUtil= HibernateCurdUtil.getInstance(TravelExpensives.class, Bike.class, Metro.class);
        TravelExpensives travelExpensives = new TravelExpensives();
        Metro metro= new Metro();
        Bike bike= new Bike();
        List<Bike> bikes = new ArrayList<>();
        bikes.add(bike);
        List<Metro> metros = new ArrayList<>();
        metros.add(metro);
        travelExpensives.setDate(new Date());
        travelExpensives.setBikes(bikes);
      travelExpensives.setMetroList(metros);
      hibernateCurdUtil.saveRecord(bike);
      hibernateCurdUtil.saveRecord(metro);
      hibernateCurdUtil.saveRecord(travelExpensives);



    }
}
